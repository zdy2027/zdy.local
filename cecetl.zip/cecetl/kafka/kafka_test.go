package kafka

import (
	"testing"
)

func TestProducter(t *testing.T) {
	//Producter()
	Consumer()
}